from __future__ import annotations
import math
import numpy as np
import trimesh
from shapely.geometry import Polygon, Point
from pinch_hanger_meshlib import *
def clip_local(level):
 res={'MASTER':12,'LOD0':10,'LOD1':8,'LOD2':6,'LOD3':4}[level];hole=Point(0,0).buffer(.0022,quad_segs=res)
 a=Polygon([(-.004,.021),(.008,.021),(.007,.010),(.006,.004),(.005,-.010),(.004,-.037),(.003,-.050),(-.001,-.055),(-.003,-.048),(-.003,-.018),(-.004,-.005)]).difference(hole);b=Polygon([(-x,y) for x,y in a.exterior.coords[::-1]]).difference(hole);m1=extrude(a,.0005,.0045);m2=extrude(b,-.0045,-.0005)
 steps={'MASTER':70,'LOD0':52,'LOD1':38,'LOD2':26,'LOD3':18}[level];sides={'MASTER':8,'LOD0':7,'LOD1':6,'LOD2':5,'LOD3':4}[level];t=np.linspace(0,TAU*2.7,steps);z=np.linspace(-.0052,.0052,steps);coil=np.column_stack([.0031*np.cos(t),.0031*np.sin(t),z]);path=np.vstack([[.010,.014,-.0045],[.007,.010,-.0047],coil,[-.007,.010,.0047],[-.010,.014,.0045]])
 return m1,m2,tube(path,.00045,sides,True)
def hanger(level):
 s=trimesh.Scene();ringN={'MASTER':128,'LOD0':96,'LOD1':64,'LOD2':40,'LOD3':24}[level];minor={'MASTER':12,'LOD0':10,'LOD1':8,'LOD2':6,'LOD3':5}[level];add(s,'CircularFrame',torus(.180,.0065,ringN,minor),'PaleBluePP','xz');add(s,'CentralHubRing',torus(.026,.0055,max(24,ringN//3),minor),'PaleBluePP','xz')
 for i,a in enumerate([0,TAU/3,2*TAU/3]):add(s,f'RadialSpoke_{i}',tube([[.027*math.cos(a),0,.027*math.sin(a)],[.174*math.cos(a),0,.174*math.sin(a)]],.0045,minor,True),'PaleBluePP','xz')
 hook=[np.array([0,.002,0]),np.array([0,.085,0]),np.array([.005,.145,0])];c=np.array([.030,.170,0])
 for a in np.linspace(math.pi,-math.pi*.62,max(18,ringN//3)):hook.append(c+[.030*math.cos(a),.030*math.sin(a),0])
 add(s,'CarryHook',tube(hook,.0048,minor,True),'PaleBluePP');j1,j2,sp=clip_local(level);link=max(4,minor-1)
 for i in range(24):
  a=TAU*(i+.5)/24;p=np.array([.180*math.cos(a),0,.180*math.sin(a)]);q=p+[0,-.036,0];add(s,f'SuspensionLink_{i:02d}',tube([p+[0,-.002,0],q+[0,.010,0]],.00125,link,True),'PaleBluePP')
  for suffix,src,mat in [('JawA',j1,'WarmWhitePP'),('JawB',j2,'WarmWhitePP'),('Spring',sp,'SpringSteel')]:m=src.copy();transform_y(m,-a,q);add(s,f'Clip_{i:02d}_{suffix}',m,mat)
 return s,{'outerDiameterMetres':.373,'frameTubeDiameterMetres':.013,'clipCount':24,'clipJawLengthMetres':.076,'pivotHoleDiameterMetres':.0044,'springWireDiameterMetres':.0009,'springTurns':2.7,'allClipsRetainedEveryLOD':True,'mechanicalLoadVerified':False}
def catmull(p,n):
 p=np.asarray(p,float);out=[]
 for k in range(n):u=k/(n-1)*(len(p)-1);i=min(len(p)-2,int(math.floor(u)));t=u-i;p0,p1,p2,p3=p[max(0,i-1)],p[i],p[i+1],p[min(len(p)-1,i+2)];out.append(.5*((2*p1)+(-p0+p2)*t+(2*p0-5*p1+4*p2-p3)*t*t+(-p0+3*p1-3*p2+p3)*t*t*t))
 return np.asarray(out)
def interp(v,n):return np.interp(np.linspace(0,1,n),np.linspace(0,1,len(v)),np.asarray(v,float))
def socks(level):
 s=trimesh.Scene();sides={'MASTER':32,'LOD0':24,'LOD1':18,'LOD2':12,'LOD3':8}[level];samples={'MASTER':40,'LOD0':30,'LOD1':22,'LOD2':16,'LOD3':12}[level];spec=[]
 for i,sign in enumerate([-1,1]):
  x=.070*sign;c=np.array([[x,0,0],[x,-.050,.002*sign],[x-.004*sign,-.100,.006*sign],[x+.008*sign,-.135,.011*sign],[x+.025*sign,-.155,.014*sign],[x+.055*sign,-.171,.014*sign],[x+.090*sign,-.179,.010*sign],[x+.116*sign,-.178,.004*sign]]);p=catmull(c,samples)
  if i==1:p[:,2]+=.005*np.sin(np.linspace(0,math.pi,len(p)))
  m=sock_shell(p,interp([.0325,.032,.031,.030,.031,.030,.024,.014],samples),interp([.0175,.017,.016,.015,.016,.015,.012,.008],samples),interp([.0017,.00155,.0011,.00086,.00080,.00080,.00085,.0009],samples),sides);add(s,f'Sock_{i}_HollowKnitShell',m,'WarmWhiteCotton');spec.append(dict(cuffCentre=p[0].tolist(),toeApprox=p[-1].tolist()))
 return s,{'pairCount':2,'openCuffDiameterApproxMetres':[.065,.035],'fabricThicknessMetres':[.0008,.0017],'overallLengthApproxMetres':.24,'toeAndCavityAreRealGeometry':True,'smoothCentrelineSamples':samples,'pairPlacement':spec}
def cloth(width,height,nu,nv):
 base=np.zeros((nv,nu,3))
 for j in range(nv):
  v=j/(nv-1);y=-height*v
  for i in range(nu):
   u=i/(nu-1)-.5;x=u*width;z=.012*math.sin(2.6*math.pi*(u+.5)+.4)*math.sin(math.pi*v)**1.18+.003*math.sin(11*u+7*v)*math.sin(math.pi*v);pin=math.exp(-((u-.41)/.055)**2-(v/.055)**2)+math.exp(-((u+.41)/.055)**2-(v/.055)**2);base[j,i]=[x,y+.009*pin,z-.006*pin]
 nrm=np.zeros_like(base)
 for j in range(nv):
  for i in range(nu):du=base[j,min(i+1,nu-1)]-base[j,max(i-1,0)];dv=base[min(j+1,nv-1),i]-base[max(j-1,0),i];nrm[j,i]=unit(np.cross(du,dv) if np.linalg.norm(np.cross(du,dv))>1e-9 else [0,0,1])
 th=np.array([[.00135 if (abs(i/(nu-1)-.5)>.47 or j/(nv-1)<.035 or j/(nv-1)>.965) else .00065 for i in range(nu)] for j in range(nv)]);top=base+nrm*th[:,:,None]/2;bot=base-nrm*th[:,:,None]/2;v=np.vstack([top.reshape(-1,3),bot.reshape(-1,3)]);f=[];off=nu*nv;ix=lambda j,i:j*nu+i
 for j in range(nv-1):
  for i in range(nu-1):a,b,c,d=ix(j,i),ix(j,i+1),ix(j+1,i+1),ix(j+1,i);f += [[a,b,c],[a,c,d],[off+a,off+c,off+b],[off+a,off+d,off+c]]
 per=[ix(0,i) for i in range(nu)]+[ix(j,nu-1) for j in range(1,nv)]+[ix(nv-1,i) for i in range(nu-2,-1,-1)]+[ix(j,0) for j in range(nv-2,0,-1)]
 for a,b in zip(per,per[1:]+per[:1]):f += [[a,off+a,off+b],[a,off+b,b]]
 return finish(v,f)
def handkerchief(level):
 nu,nv={'MASTER':(80,80),'LOD0':(56,56),'LOD1':(38,38),'LOD2':(24,24),'LOD3':(14,14)}[level];s=trimesh.Scene();add(s,'WovenHandkerchiefWithFoldedHem',cloth(.38,.38,nu,nv),'PaleMintCotton');return s,{'finishedSizeMetres':[.38,.38],'baseFabricThicknessMetres':.00065,'foldedHemThicknessMetres':.00135,'pinchLocationsNormalized':[-.41,.41],'stitchThreadNotGeometry':True}
def review(h,sock,hand):
 s=trimesh.Scene()
 def ins(src,p,T):
  for n,g in src.geometry.items():m=g.copy();m.apply_transform(T);s.add_geometry(m,node_name=p+n,geom_name=p+n)
 T=np.eye(4);T[:3,3]=[0,.30,0];ins(h,'H_',T);T=np.eye(4);T[:3,3]=[.055,.205,-.120];ins(sock,'S_',T);a=math.radians(-38);T=np.eye(4);T[:3,:3]=[[math.cos(a),0,math.sin(a)],[0,1,0],[-math.sin(a),0,math.cos(a)]];T[:3,3]=[-.080,.200,.095];ins(hand,'K_',T);return s
