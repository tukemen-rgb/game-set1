from __future__ import annotations
import argparse,hashlib,json
from pathlib import Path
import numpy as np
import trimesh
from pinch_hanger_models import hanger,socks,handkerchief,review
LEVELS=['MASTER','LOD0','LOD1','LOD2','LOD3']
def verify(scene):
 c=[]
 for n,g in scene.geometry.items():
  assert np.isfinite(g.vertices).all() and np.isfinite(g.vertex_normals).all() and np.all(g.area_faces>1e-14),n
  w=g.copy();w.visual=trimesh.visual.ColorVisuals(mesh=w);w.merge_vertices(digits_vertex=8);w.remove_unreferenced_vertices();w.fix_normals(multibody=True);assert w.is_watertight and w.is_winding_consistent and w.volume>0,n;_,cnt=np.unique(w.edges_sorted,axis=0,return_counts=True);assert np.all(cnt==2),n
  c.append(dict(component=n,triangles=len(g.faces),vertices=len(g.vertices),boundaryEdges=0,nonmanifoldEdges=0,materialVolumeM3=float(w.volume)))
 return dict(triangles=sum(x['triangles'] for x in c),components=c,boundsMetres=scene.bounds.tolist())
def export(scene,out,stem):
 glb=out/(stem+'.glb');glb.write_bytes(scene.export(file_type='glb'));r=trimesh.load(glb,force='scene',process=False);tri=sum(len(g.faces) for g in r.geometry.values());assert tri==sum(len(g.faces) for g in scene.geometry.values()) and np.allclose(r.bounds,scene.bounds,atol=1e-6)
 d=out/stem;d.mkdir(exist_ok=True);obj,files=trimesh.exchange.obj.export_obj(scene,include_normals=True,include_texture=True,return_texture=True);(d/(stem+'.obj')).write_text(obj)
 for n,data in files.items():p=d/n;p.write_text(data) if isinstance(data,str) else p.write_bytes(data)
 assert sum(len(g.faces) for g in trimesh.load(d/(stem+'.obj'),force='scene',process=False).geometry.values())==tri
 return hashlib.sha256(glb.read_bytes()).hexdigest()
def run(out):
 out.mkdir(parents=True,exist_ok=True);assets=[];lod0={};builders=[('RoundPinchHanger360_24Clips',hanger),('AnkleSockPair240',socks),('Handkerchief380Pinned',handkerchief)]
 for name,b in builders:
  levels=[]
  for L in LEVELS:
   scene,spec=b(L);r=verify(scene);levels.append(dict(level=L,sha256=export(scene,out,name+'_'+L),glbRoundtrip=True,objRoundtrip=True,**r));print(name,L,r['triangles'],flush=True)
   if L=='LOD0':lod0[name]=scene
  counts=[x['triangles'] for x in levels];assert all(a>b for a,b in zip(counts,counts[1:]));assets.append(dict(asset=name,designMeasurements=spec,levels=levels))
 rv=review(lod0[builders[0][0]],lod0[builders[1][0]],lod0[builders[2][0]]);rr=verify(rv);sha=export(rv,out,'PinchHangerSmallLaundryReview_LOD0');manifest=dict(id='PinchHangerSmallLaundryReview_LOD0',triangles=rr['triangles'],sha256=sha,formalBenchmarkSceneChanged=False,unityVerified=False,placement='diagnostic arrangement only; hanger + socks + handkerchief, metres Y-up',knownLimitations=['cloth-to-clip contact is visually arranged, not physics-solved','clip spring preload/load not simulated','Unity coordinate/material/LOD parity pending']);(out/'PinchHangerSmallLaundryReview.manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 report=dict(status='EXTERNAL_GEOMETRY_CHECKED_NOT_VISUAL_PASS',assets=assets,reviewIntegration=manifest,checks=['finite vertices/normals','no degenerate faces','component welded watertightness','consistent winding and positive material volume','edge incidence exactly two','GLB triangle/bounds roundtrip','OBJ triangle roundtrip','strict MASTER>LOD0>LOD1>LOD2>LOD3 triangle reduction'],unityCompile=False,unityImport=False,unityRender=False,temporalVerified=False,performanceVerified=False,mechanicalContactVerified=False,visualFidelityScore=None);(out/'geometry_verification.json').write_text(json.dumps(report,indent=2)+'\n');return report
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);run(ap.parse_args().output)
