from __future__ import annotations
import math
import numpy as np
import trimesh
from PIL import Image
TAU=2*math.pi
MATERIALS={
'PaleBluePP':dict(color=[.35,.58,.70],roughness=.52,metallic=0.,tile=.06),
'WarmWhitePP':dict(color=[.74,.73,.67],roughness=.55,metallic=0.,tile=.055),
'SpringSteel':dict(color=[.48,.50,.52],roughness=.36,metallic=1.,tile=.04),
'WarmWhiteCotton':dict(color=[.78,.78,.73],roughness=.82,metallic=0.,tile=.028),
'PaleMintCotton':dict(color=[.47,.68,.59],roughness=.78,metallic=0.,tile=.035)}
def unit(v):
 v=np.asarray(v,float);n=np.linalg.norm(v)
 if n<1e-12:raise ValueError('zero vector')
 return v/n
def texture(spec,name,size=128):
 yy,xx=np.mgrid[:size,:size];u=xx/size;v=yy/size;p=np.sin(TAU*(17*u+13*v))*np.sin(TAU*(19*v-11*u));q=np.sin(TAU*41*u)*np.sin(TAU*37*v)
 grain,amp,rd=(.7*p+.3*q,.020,.035) if 'Cotton' in name else ((.5*np.sin(TAU*47*u)+.5*p,.010,.022) if 'Steel' in name else (.72*p+.28*q,.010,.018))
 base=np.clip(np.asarray(spec['color'])[None,None,:]*(1+amp*grain[:,:,None]),0,1);rough=np.clip(spec['roughness']+rd*grain,.04,1);orm=np.stack([np.ones_like(rough),rough,np.full_like(rough,spec['metallic'])],-1)
 return Image.fromarray(np.uint8(base*255)),Image.fromarray(np.uint8(orm*255))
def apply_material(m,name,axis='xy'):
 spec=MATERIALS[name];base,orm=texture(spec,name);v=m.vertices
 uv=(np.column_stack([v[:,0]+.31*v[:,2],v[:,1]+.17*v[:,2]]) if axis=='xy' else (np.column_stack([v[:,2]+.23*v[:,0],v[:,1]+.11*v[:,0]]) if axis=='yz' else np.column_stack([v[:,0],v[:,2]])))/spec['tile']
 mat=trimesh.visual.material.PBRMaterial(name=name,baseColorTexture=base,metallicRoughnessTexture=orm,metallicFactor=1.,roughnessFactor=1.);m.visual=trimesh.visual.TextureVisuals(uv=uv,material=mat);return m
def finish(v,f):
 m=trimesh.Trimesh(vertices=np.asarray(v,float),faces=np.asarray(f,np.int64),process=False);m.merge_vertices(digits_vertex=9);m.remove_unreferenced_vertices();m.fix_normals(multibody=True);return m
def tube(path,radius,sides=10,cap=True):
 path=np.asarray(path,float);rr=np.broadcast_to(radius,(len(path),)).astype(float);frames=[];prev=None
 for i in range(len(path)):
  t=unit(path[min(i+1,len(path)-1)]-path[max(i-1,0)]);n=np.cross(t,[0,1,0]) if prev is None else prev-t*np.dot(prev,t)
  if np.linalg.norm(n)<1e-7:n=np.cross(t,[1,0,0])
  n=unit(n);b=unit(np.cross(t,n));frames.append((n,b));prev=n
 v=[];f=[];rings=[]
 for p,r,(n,b) in zip(path,rr,frames):
  ring=[]
  for j in range(sides):a=TAU*j/sides;ring.append(len(v));v.append(p+r*(n*math.cos(a)+b*math.sin(a)))
  rings.append(ring)
 for i in range(len(rings)-1):
  for j in range(sides):k=(j+1)%sides;a,b=rings[i][j],rings[i][k];c,d=rings[i+1][k],rings[i+1][j];f += [[a,b,c],[a,c,d]]
 if cap:
  a0=len(v);v.append(path[0]);a1=len(v);v.append(path[-1])
  for j in range(sides):k=(j+1)%sides;f += [[a0,rings[0][k],rings[0][j]],[a1,rings[-1][j],rings[-1][k]]]
 return finish(v,f)
def torus(R,r,ns,ms,centre=(0,0,0)):
 v=[];f=[];c=np.asarray(centre,float)
 for i in range(ns):
  a=TAU*i/ns
  for j in range(ms):q=TAU*j/ms;v.append(c+[(R+r*math.cos(q))*math.cos(a),r*math.sin(q),(R+r*math.cos(q))*math.sin(a)])
 ix=lambda i,j:(i%ns)*ms+(j%ms)
 for i in range(ns):
  for j in range(ms):a,b,c,d=ix(i,j),ix(i,j+1),ix(i+1,j+1),ix(i+1,j);f += [[a,b,c],[a,c,d]]
 return finish(v,f)
def extrude(poly,z0,z1):
 import shapely
 tris=[np.asarray(t.exterior.coords)[:3] for t in shapely.constrained_delaunay_triangles(poly).geoms];coords={};key=lambda p:(round(float(p[0]),12),round(float(p[1]),12))
 for t in tris:
  for p in t:coords.setdefault(key(p),len(coords))
 for ring in [poly.exterior,*poly.interiors]:
  for p in list(ring.coords)[:-1]:coords.setdefault(key(p),len(coords))
 pts=np.zeros((len(coords),2))
 for k,i in coords.items():pts[i]=k
 n=len(pts);v=np.zeros((2*n,3));v[:n,:2]=pts;v[:n,2]=z0;v[n:,:2]=pts;v[n:,2]=z1;f=[]
 for t in tris:
  ids=[coords[key(p)] for p in t];area=np.cross(np.r_[pts[ids[1]]-pts[ids[0]],0],np.r_[pts[ids[2]]-pts[ids[0]],0])[2]
  if area<0:ids=[ids[0],ids[2],ids[1]]
  f += [[n+ids[0],n+ids[1],n+ids[2]],[ids[0],ids[2],ids[1]]]
 for ring in [poly.exterior,*poly.interiors]:
  rr=list(ring.coords)
  for p,q in zip(rr,rr[1:]):a,b=coords[key(p)],coords[key(q)];f += [[a,b,n+b],[a,n+b,n+a]]
 return finish(v,f)
def transform_y(m,a,t=(0,0,0)):
 c,s=math.cos(a),math.sin(a);R=np.array([[c,0,s],[0,1,0],[-s,0,c]]);m.vertices=m.vertices@R.T+np.asarray(t,float);m.fix_normals(multibody=True);return m
def add(scene,name,m,mat,axis='xy'):apply_material(m,mat,axis);scene.add_geometry(m,node_name=name,geom_name=name)
def frames(path):
 path=np.asarray(path,float);out=[];prev=None
 for i in range(len(path)):
  t=unit(path[min(i+1,len(path)-1)]-path[max(i-1,0)]);n=np.cross(t,[0,0,1]) if prev is None else prev-t*np.dot(prev,t)
  if np.linalg.norm(n)<1e-7:n=np.cross(t,[1,0,0])
  n=unit(n);b=unit(np.cross(t,n));out.append((t,n,b));prev=n
 return out
def sock_shell(path,ra,rb,th,sides):
 path=np.asarray(path,float);fr=frames(path);v=[];outer=[];inner=[]
 for i,(p,(t,n,b)) in enumerate(zip(path,fr)):
  ro=[];ri=[]
  for j in range(sides):
   a=TAU*j/sides;d=n*(ra[i]*math.cos(a))+b*(rb[i]*math.sin(a));di=n*(max(.001,ra[i]-th[i])*math.cos(a))+b*(max(.001,rb[i]-th[i])*math.sin(a));ro.append(len(v));v.append(p+d);ri.append(len(v));v.append(p+di)
  outer.append(ro);inner.append(ri)
 f=[]
 for i in range(len(path)-1):
  for j in range(sides):k=(j+1)%sides;f += [[outer[i][j],outer[i][k],outer[i+1][k]],[outer[i][j],outer[i+1][k],outer[i+1][j]],[inner[i][j],inner[i+1][k],inner[i][k]],[inner[i][j],inner[i+1][j],inner[i+1][k]]]
 for j in range(sides):k=(j+1)%sides;f += [[outer[0][j],inner[0][k],outer[0][k]],[outer[0][j],inner[0][j],inner[0][k]]]
 t=fr[-1][0];oi=len(v);v.append(path[-1]+t*.006);ii=len(v);v.append(path[-1]+t*.003)
 for j in range(sides):k=(j+1)%sides;f += [[outer[-1][j],outer[-1][k],oi],[inner[-1][j],ii,inner[-1][k]]]
 return finish(v,f)
